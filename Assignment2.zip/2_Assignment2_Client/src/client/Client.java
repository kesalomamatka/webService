package client;

import handlers.ServiceHandler;

import java.net.URL;
import java.util.Scanner;

import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;
import org.apache.xmlrpc.client.util.ClientFactory;

public class Client {

	public static void main(String[] args) {

		try {

			XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
			//run as java application
			
			// config.setServerURL(new
			// URL("http://localhost:8080/mg_XmlRpcServlet/xmlrpc"));
			config.setServerURL(new URL("http://app3.cc.puv.fi/2_Assignment2_Server_5/xmlrpc"));
			//config.setServerURL(new URL("http://app3.cc.puv.fi/XMLRPC_Servlet_Ex33_ee/xmlrpc"));

			XmlRpcClient client = new XmlRpcClient();

			client.setConfig(config);

			
			// In the following we use dynamic proxy
			ClientFactory clientFactory = new ClientFactory(client);
			ServiceHandler servicHandler = (ServiceHandler) clientFactory.newInstance(ServiceHandler.class);

			System.out.println("Dynamic Proxy:");
			//results = servicHandler.sortString("Hopefully, We are LEARNing something...");
			
			
			boolean flag = true;
			while(flag){
				System.out.println("-----Enter-----\n1.Add Employee\n2.Search Employee\n3.Delete Employee\n4.All Employee");
				Scanner scanner = new Scanner(System.in);
				int choose = scanner.nextInt();
				
				if(choose==1){				//1.Add Employee
					StringBuilder text = new StringBuilder();
				
					System.out.println("Employee ID:");
					int ID = scanner.nextInt();
					text.append("ID: "+ID+",");
					
					System.out.println("Employee name:");
					String name = scanner.next();
					text.append("name: "+name+",");
					
					System.out.println("Employee job:");
					String job = scanner.next();
					text.append("job: "+job+",");
					
					System.out.println("Employee salary:");
					int salary = scanner.nextInt();
					text.append("salary: "+salary+"\n");
					
					
					String response = servicHandler.addEmployee(text+"");

				}else if(choose==2){		//2.Search Employee
					System.out.println("Search Employee with Employee's ID:");
					int ID = scanner.nextInt();
					String response =servicHandler.searchEmp("ID: " +ID);
					System.out.println(response);
					
				}else if(choose==3){		//3.Delete Employee
					System.out.println("Delete Employee with Employee's ID:");
					int ID = scanner.nextInt();
					String response =servicHandler.deleteEmp("ID: " +ID);
					System.out.println(response);
					
				}else if(choose==4){
					System.out.println(servicHandler.getAllEmp());

				}else System.out.println("Invalid input");
				
				
			}
			
			String results = servicHandler.addEmployee("");
					
			System.out.println(results);

		}

		catch (Exception e)

		{

			System.out.println("Exception: " + e.getMessage());

		}

	}

}