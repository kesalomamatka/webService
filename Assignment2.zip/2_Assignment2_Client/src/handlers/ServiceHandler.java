

//This is handlers. ServiceHandler.java file

package handlers;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface ServiceHandler {
	
	public String addEmployee(String text);
	public String searchEmp(String searchStr) throws FileNotFoundException;
	 public String deleteEmp(String searchStr) throws IOException;
	public String getAllEmp();
}
