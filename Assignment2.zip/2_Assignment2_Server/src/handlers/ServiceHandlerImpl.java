
//This is handlers. ServiceHandlerImpl.java file

package handlers;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.Scanner;

public class ServiceHandlerImpl implements ServiceHandler {

	String path = "/var/lib/tomcat7/webapps/public_files/";
	String file = "Employee.txt"; 
	
	Hashtable<String, String> employee  = new Hashtable<String, String>();


	public String addEmployee(String text) {
		
		StringBuilder read = new StringBuilder();
		String employee = getAllEmp();
		if(employee != null) {
			read.append(employee);
		}
		if(text != null) {
			read.append(text);
			read.append("\n");
		}
		File filePath = new File(path, file);
		
		try {
			PrintWriter writer = new PrintWriter(filePath, "UTF-8");
			writer.print(read.toString());
			writer.close();
		}catch (IOException e) {
		    return "Exception: " + e.getMessage();
		}
		
		return "Successful!";
	}
	
	 public String searchEmp(String searchStr) throws FileNotFoundException{
	        Scanner scan = new Scanner(new File(path+file));
	        //System.out.println(path+file);
	        while(scan.hasNext()){
	            String line = scan.nextLine().toString();
	           //String line = scan.nextLine().toLowerCase().toString();

	            if(line.contains(searchStr)){
	                System.out.println(line);
	                return line;
	            }
	        }
	        return "not found";
	    }
	 
	 public String getAllEmp() {
			File filePath = new File(path, file);
			if(!filePath.isFile()) {
				return "";
			}
			
			StringBuilder sb = new StringBuilder();
			
			try {
				InputStream is = new FileInputStream(filePath);
				BufferedReader buf = new BufferedReader(new InputStreamReader(is));
		        
				String line = buf.readLine();     
				while(line != null){
				   sb.append(line).append("\n");
				   line = buf.readLine();
				}
				buf.close();
			} catch (IOException e) {
				return "Exception: " + e.getMessage();
			}
			
			return sb.toString();
		}
	 public String deleteEmp(String searchStr) throws IOException	{
		 File inputFile = new File(path+file);
		 File tempFile = new File(path+"myTempFile.txt");

		 BufferedReader reader = new BufferedReader(new FileReader(inputFile));
		 BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

		 String deleteEmp = searchEmp(searchStr);
		 
		 String lineToRemove = deleteEmp;
		 String currentLine;

		 while((currentLine = reader.readLine()) != null) {
		     // trim newline when comparing with lineToRemove
		     String trimmedLine = currentLine.trim();
		     if(trimmedLine.equals(lineToRemove)) continue;
		     writer.write(currentLine + System.getProperty("line.separator"));
		 }
		 writer.close(); 
		 reader.close(); 
		 boolean successful = tempFile.renameTo(inputFile);
		 if(successful) return "removed";
		 else return "not found";
	 }


}
