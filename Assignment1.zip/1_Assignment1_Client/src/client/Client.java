package client;

import handlers.IActionHandler;

import java.net.URL;
import java.util.Scanner;
import java.util.Vector;

import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;
import org.apache.xmlrpc.client.XmlRpcCommonsTransportFactory;
import org.apache.xmlrpc.client.util.ClientFactory;

public class Client {

	private XmlRpcClient client;
	private IActionHandler actionHandler;
	
	
	public void init(XmlRpcClientConfigImpl config) {
		// create & configure client
		// XmlRpcClient client = new XmlRpcClient();
		client = new XmlRpcClient();
		client.setTransportFactory(new XmlRpcCommonsTransportFactory(client));
		client.setConfig(config);
		
		// create action handler
		ClientFactory cFactory = new ClientFactory(client);
		//IActionHandler actionHandler;
		actionHandler = (IActionHandler)cFactory.newInstance(IActionHandler.class);
	}

	public void printRemoteFileList() throws XmlRpcException {

		Vector<String> remoteFileList = actionHandler.getFileList();
		for (String file : remoteFileList) {
			System.out.println(file);
		}
	}
	
	public String downloadRemoteFile(String file) throws XmlRpcException {
		return actionHandler.readFileContent(file);
	}
	
	public void uploadFile(String fileName,String text) throws XmlRpcException {
	
		String response = actionHandler.writeFileContent(fileName, text);
		System.out.println(response);
	}
	
	public static void main(String[] args) {
		if (args.length < 1) {
			System.out.println("Usage: java Client [port]");
			System.exit(-1);
		}
/*	if (args.length < 2) {
			System.out.println("Usage: java Client [server] [port]");
			System.exit(-1);
		}

 * 
 * 
 * */
		Client client = new Client();
		XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
		try(Scanner scanner = new Scanner(System.in)) {
			//config.setServerURL(new URL("http://" + args[0] + ":" + Integer.parseInt(args[1]) + "/"));
			config.setServerURL(new URL("http://shell.puv.fi:" + Integer.parseInt(args[0]) + "/"));

			client.init(config);
			
			boolean flag = true;
			while (flag){
				System.out.println("-------Assignment1--------");
				client.printRemoteFileList();
				
				System.out.println("Write file name to create or read:");
				String fileName = scanner.next();
				
				System.out.println("Read content: \n");
				String content = client.downloadRemoteFile(fileName);
				if(content != null) {
					System.out.println(content);
				}else{ System.out.println("no content yet \n");}
				
				System.out.println("Write content: (Write 'done' for upload. )");
				//String content = client.downloadRemoteFile(fileName);
				StringBuilder text = new StringBuilder();
				if(content != null) {
					text.append(content);
				}
				String str = "";
				while((str = scanner.nextLine()).compareToIgnoreCase("done") != 0) {
					text.append(str);
					text.append("\n");
				}
				client.uploadFile(fileName,text.toString());
				System.out.println("\n----------CONTINULE?(y/n)--------\n");
				if((str = scanner.nextLine()).compareToIgnoreCase("n") == 0){
					flag = false;
				}else flag = true;
			}
			
			

		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		}
	}
}