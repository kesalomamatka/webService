
//This is handlers.IActionHandler.java

package handlers;

import java.util.Vector;

public interface IActionHandler {
	public String getDate(String name);
	
	String Numbers(Vector<Integer> numbers);
	
	//Integer getMinNumber(Vector<Integer> numbers);

	//Integer getMaxNumber(Vector<Integer> numbers);
	
	//Integer getAvgNumber(Vector<Integer> numbers);

}
