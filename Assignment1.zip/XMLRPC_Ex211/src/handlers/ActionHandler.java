
//This is handlers.ActionHandler.java

package handlers;

import java.text.DateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Vector;

public class ActionHandler implements IActionHandler {
	public String getDate(String name) {
		Date date = new Date();

		return "Hello " 
				+ name 
				+ "! By the way, today is "
				+ DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.LONG).format(new Date());
	}
	
	/*
	public Integer getMinNumber(Vector<Integer> numbers) {
		return Collections.min(numbers);
	}
	
	public Integer getMaxNumber(Vector<Integer> numbers) {
		return Collections.max(numbers);
	}
	
	public Integer getAvgNumber(Vector<Integer> numbers) {
		int sum = 0;
		
		for (int num : numbers) {
		        sum += num;    
		    }
		
		return sum/numbers.size();
	}
	*/
	public String Numbers(Vector<Integer> numbers){
		int sum = 0;
		
		for (int num : numbers) {
		        sum += num;    
		    }
		String ave  = sum/numbers.size()+"";
		
		return 	"Smallest number: " + Collections.min(numbers) +"\n"
			+ 	"Biggest number: "+ Collections.max(numbers) +"\n"
			+	"Average of numbers: " + ave.toString() 	+"\n";
	}		

}
