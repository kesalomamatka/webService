package server;

import handlers.ActionHandler;
import handlers.IActionHandler;

import java.io.File;
import java.io.IOException;

import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.server.PropertyHandlerMapping;
import org.apache.xmlrpc.server.XmlRpcServer;
import org.apache.xmlrpc.server.XmlRpcServerConfigImpl;
import org.apache.xmlrpc.webserver.WebServer;

public class Server {

	public static void main(String[] args) {
		if (args.length < 1) {
			System.out.println("Usage: java Server [port]");
			System.exit(-1);
		}
		
		System.out.println("Attempting to start XML-RPC server...");
		//final String propertyFile = "resources/myHandler.properties".replace(File.separatorChar, '/');
		//final String propertyFile = "resource"+File.separator +"myHandler.properties";

		try {
			int port = Integer.parseInt(args[0]);
			
			PropertyHandlerMapping phm = new PropertyHandlerMapping();
			phm.addHandler(IActionHandler.class.getName(), ActionHandler.class);
			//ClassLoader cl = Thread.currentThread().getContextClassLoader();
			//mapping.load(cl, propertyFile);

			WebServer webServer = new WebServer(port);
			XmlRpcServer server = webServer.getXmlRpcServer();
			server.setHandlerMapping(phm);
			webServer.start();

			System.out.println("Server is successfully started at port " + args[0]);

		} catch (NumberFormatException|XmlRpcException|IOException e) {
			System.out.println(e.getMessage());
		}
	}
}