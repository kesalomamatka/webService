package handlers;

import java.util.Vector;

public interface IActionHandler {

	Vector<String> getFileList();
	
	String readFileContent(String file);
	
	String writeFileContent(String file, String text);
}