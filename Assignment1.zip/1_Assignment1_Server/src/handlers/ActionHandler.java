package handlers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Vector;

public class ActionHandler implements IActionHandler {
	
	private final File path = new File("files" + File.separator);

	@Override
	public Vector<String> getFileList() {
		path.mkdirs();
		String[] fileList = path.list();
		return new Vector<String>(Arrays.asList(fileList));
	}

	@Override
	public String readFileContent(String file) {
		File filePath = new File(path, file);
		if(!filePath.isFile()) {
			return "";
		}
		
		StringBuilder sb = new StringBuilder();
		
		try {
			InputStream is = new FileInputStream(filePath);
			BufferedReader buf = new BufferedReader(new InputStreamReader(is));
	        
			String line = buf.readLine();     
			while(line != null){
			   sb.append(line).append("\n");
			   line = buf.readLine();
			}
			buf.close();
		} catch (IOException e) {
			return "Exception: " + e.getMessage();
		}
		
		return sb.toString();
	}

	@Override
	public String writeFileContent(String file, String text) {
		File filePath = new File(path, file);
		
		try {
			PrintWriter writer = new PrintWriter(filePath, "UTF-8");
			writer.print(text);
			writer.close();
		}catch (IOException e) {
		    return "Exception: " + e.getMessage();
		}
		
		return "Successful!";
	}
}