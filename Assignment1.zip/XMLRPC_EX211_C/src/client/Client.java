//This is client.Client.java file. 4006

//10000-10100

package client;

import java.net.URL;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Vector;

import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;
import org.apache.xmlrpc.client.XmlRpcCommonsTransportFactory;

public class Client {

	public static void main(String[] args) {

		XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();

		try {
			
			//config.setServerURL(new URL("http://shell.puv.fi:" + Integer.parseInt(args[0]) + "/"));

			config.setServerURL(new URL("http://127.0.0.1:" + Integer.parseInt(args[0]) + "/"));

			XmlRpcClient client = new XmlRpcClient();

			client.setTransportFactory(new XmlRpcCommonsTransportFactory(client));

			client.setConfig(config);
					//define array of object type
			Object[] params = new Object[] { new String("Amanda") };
			String msg = (String) client.execute("handlers.ActionHandler.getDate", params);
			System.out.println(msg);
			
			// pass the array of numbers as an object of java.util.Vector
			/*

			Vector<Integer> numberList = new Vector<Integer>(
					Arrays.asList(new Integer(5), new Integer(10), new Integer(15)));
			*/
			

			Vector<Integer> numberList = new Vector<Integer>();
			params = new Object[] { numberList };
			

			System.out.println("Enter numbers: (done to stop)");
/*
			Scanner scanner = new Scanner(System.in);
					Integer num = Integer.parseInt(scanner.nextLine());
					numberList.add(num);
					String str = "";
					while((str= scanner.nextLine()).compareToIgnoreCase("done") != 0) {
						
						num = Integer.parseInt(scanner.nextLine());
						numberList.add(num);
					}
					*/
			
			Scanner scanner = new Scanner(System.in);
			Integer num=0;
			String str = "";
			do{
				num = Integer.parseInt(scanner.nextLine());
				numberList.add(num);
			}while((str= scanner.nextLine()).compareToIgnoreCase("done") != 0);
					
			
			String s = (String)client.execute("handlers.ActionHandler.Numbers", params);
			System.out.println("Result: \n"+s.toString());
			/*
			Integer min = (Integer)client.execute("handlers.ActionHandler.getMinNumber", params);
			System.out.println("Smallest number: " + min.toString());
			
			Integer max = (Integer)client.execute("handlers.ActionHandler.getMaxNumber", params);
			System.out.println("Biggest number: "+max.toString());
			
			Integer avg = (Integer)client.execute("handlers.ActionHandler.getAvgNumber", params);
			System.out.println("Average of numbers: "+avg.toString());
			*/
			
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		}
	}
}
