package client;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.xml.namespace.QName;

import org.apache.axis2.AxisFault;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.rpc.client.RPCServiceClient;

import ws.customer.data.Customer;

public class CustomerRPCClient {

	private static final String CUSTOMERSERVICE = "http://service.customer.ws";
	
	Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	PreparedStatement ps = null;
	
	String dbUserName= "";
	String dbPassword=  "";
	String dbName =  "";
	String dbTableName="";
	
	
	private RPCServiceClient serviceClient = null;
	
	public void init(String erp) throws AxisFault {
		serviceClient = new RPCServiceClient();
		Options options = serviceClient.getOptions();
		EndpointReference targetEPR = new EndpointReference(erp);
		options.setTo(targetEPR);
	}
	
	public void addCustomer(Customer customer) throws AxisFault {
		
		QName opSetCustomer = new QName(CUSTOMERSERVICE, "setCustomer");
		Object[] opSetCustomerArgs = new Object[] { customer };
		// We call invokeBlocking() method to get server response
		serviceClient.invokeRobust(opSetCustomer, opSetCustomerArgs);
	}
	
	public Customer getCustomerById(int id) throws AxisFault {
		QName opGetCustomer = new QName(CUSTOMERSERVICE, "getCustomer");
		Object[] opGetCustomerArgs = new Object[] { id };
		Class[] returnTypes = new Class[] { Customer.class };
		Object[] response = serviceClient.invokeBlocking(opGetCustomer, opGetCustomerArgs, returnTypes);
		return (Customer)response[0];
	}
	
	public Customer[] getCustomerInShoppingAmountRange(float min, float max) throws AxisFault {
		QName op = new QName(CUSTOMERSERVICE, "getCustomerInShoppingAmountRange");
		Object[] opArgs = new Object[] { min, max };
		Class[] returnTypes = new Class[] { Customer[].class };
		Object[] response = serviceClient.invokeBlocking(op, opArgs, returnTypes);
		return (Customer[])response[0];
	}
	
	public void saveToDatabase(String name, Integer id, float amount, boolean privileged, float discount) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://mysql.cc.puv.fi:3306/" + dbName;
			conn = DriverManager.getConnection(url, dbUserName, dbPassword);
			stmt = conn.createStatement();
			ps = conn.prepareStatement("insert into " + dbTableName+ "(name, id, amount, privileged, discount) " + "values(?,?,?,?,?)");
			ps.setString(1, name);
			ps.setInt(2, id);
			ps.setFloat(3, amount);
			ps.setBoolean(4, privileged);
	    	ps.setFloat(5, discount);
	    	int counter = ps.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				System.out.print("position 1" + e.getMessage());
			}
		}
		
	}
	
	public void readFromDatabase()  {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://mysql.cc.puv.fi:3306/" + dbName;
			conn = DriverManager.getConnection(url, dbUserName, dbPassword);
			stmt = conn.createStatement();
			String query = "select * from " + dbTableName;
			ResultSet resultSet = stmt.executeQuery(query);
			
			 while (resultSet.next()) {
				 printOutDatabase(resultSet.getString(1),resultSet.getInt(2),resultSet.getFloat(3),resultSet.getBoolean(4),resultSet.getFloat(5));
					
			 }
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				System.out.print("position 2" + e.getMessage());
			}
		}
		
	}
	public void printOutDatabase(String name, Integer id, float amount, boolean privileged, float discount) {
		System.out.println("Customer name : " + name);
		System.out.println("Customer ID : " +  id);
		System.out.println("Shopping amount : " + amount);
		System.out.println("Customer is privileged? : " + privileged);
		System.out.println("Discount amount : " + discount);
	}
	
	public void printCustomer(Customer customer) {
		System.out.println("Customer name : " + customer.getCustomerName());
		System.out.println("Customer ID : " + customer.getCustomerID());
		System.out.println("Shopping amount : " + customer.getShoppingAmount());
		System.out.println("Customer is privileged? : " + customer.getPrivileged());
		System.out.println("Discount amount : " + customer.getDiscount());
		//save the filter out customer to database
		//saveToDatabase(customer.getCustomerName(),customer.getCustomerID(),customer.getShoppingAmount(),customer.getPrivileged(),customer.getDiscount());
	}
	
	public static void main(String[] args1) throws AxisFault {
		// connect to web service
		String erp = "http://localhost:8080/axis2/services/e1500951_CustomerService";
		CustomerRPCClient client = new CustomerRPCClient();
		client.init(erp);

		// create and add customers
		int[] ids = { 40090, 51000, 60600 };
		String[] names = { "Zhi", "Hao", "Tan" };
		float[] shoppinGAmounts = { 123.54f, 320.40f, 558.89f };
		boolean[] priviliged = { true, true, false };
		int[] discountPercentages = { 6, 10, 7 };
		
		Customer customer = null;
		for (int i = 0; i < ids.length; i++) {
			customer = new Customer();
			customer.setCustomerName(names[i]);
			customer.setCustomerID(ids[i]);
			customer.setShoppingAmount(shoppinGAmounts[i]);
			customer.setPrivileged(priviliged[i]);
			customer.setDiscountPercentage(discountPercentages[i]);

			client.addCustomer(customer);
			client.saveToDatabase(names[i],ids[i],shoppinGAmounts[i],priviliged[i],discountPercentages[i]	);
		}

		
		float min = 100f, max = 300f;
		Customer[] result = client.getCustomerInShoppingAmountRange(min, max);
		for (Customer cus : result) {
			client.printCustomer(cus);
		}
		
		System.out.println("-----Read From Database----");
		client.readFromDatabase();
		
	}
}