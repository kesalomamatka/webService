package server;

import handlers.ActionHandler;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.server.PropertyHandlerMapping;
import org.apache.xmlrpc.server.XmlRpcServerConfigImpl;
import org.apache.xmlrpc.webserver.XmlRpcServletServer;

public class XmlRpcServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	String servletPath=null;
	String separator = System.getProperty("file.separator");
	String fileLocationName="resources";
	
	private XmlRpcServletServer server = null;
	private XmlRpcServerConfigImpl serverConfig;
	private PropertyHandlerMapping mapping = null;

	public void init() throws ServletException {
		servletPath = getServletContext().getRealPath(separator);
		ActionHandler.fileLocation = servletPath + separator + fileLocationName + separator;
		
		try {
			server = new XmlRpcServletServer();
			mapping = new PropertyHandlerMapping();

			// Here we define handlers for the server.

			mapping.addHandler("service", handlers.ActionHandler.class);
			mapping.addHandler(handlers.IActionHandler.class.getName(),
					handlers.ActionHandler.class);

			server.setHandlerMapping(mapping);
			serverConfig = (XmlRpcServerConfigImpl) server.getConfig();
			serverConfig.setEnabledForExceptions(true);
			serverConfig.setEnabledForExtensions(true);
			server.setConfig(serverConfig);
		} catch (XmlRpcException e) {
			e.getMessage();
		}
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html><head><title>XMLRPC Servlet Response</title></head><body>");
		out.println("<p>Sorry, this servlet does not handle HTTP GET requests!</p>");
		out.println("PATH: ");
		out.println(servletPath + separator + fileLocationName + separator);
		
		out.println("</body></html>");
		out.close();

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// Here we call the XmlRpcServletServer to execute the request.
		server.execute(request, response);
	}
}