package handlers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Vector;

public class ActionHandler implements IActionHandler {

	public static String fileLocation = null;

	@Override
	public Vector<String> getFileList() {
		File fileDir = new File(fileLocation);
		
		System.out.println("location: " + fileLocation);
		
		String[] fileList = fileDir.list();

		Vector<String> v = new Vector<String>();
		for (String f : fileList)
			v.add(f);

		return v;

	}
	
	@Override
	public String uploadFile(byte[] fileContent, String fileName) {

		File fileDirectory = new File(fileLocation );
		 if (!fileDirectory.exists()) {
			 fileDirectory.mkdirs();
	        }

		File file = new File(fileLocation + fileName);
		
		FileOutputStream fos = null;

		try {
			fos = new FileOutputStream(file);
			fos.write(fileContent);
			fos.close();
		} catch (FileNotFoundException e) {
			return e.getMessage();
		} catch (IOException e) {
			return e.getMessage();
		}

		return fileName + " : " + file.getAbsolutePath();
	}

	@Override
	public byte[] downloadFile(String fileName) {

		File file = new File(fileLocation + fileName);
		
		
		
		FileInputStream fis = null;
		byte[] fileContent = null;

		try {
			fis = new FileInputStream(file);
			fileContent = new byte[fis.available()];
			fis.read(fileContent);
			fis.close();

		} catch (FileNotFoundException e) {
			return e.getMessage().getBytes();
		} catch (IOException e) {
			return e.getMessage().getBytes();
		}

		return fileContent;
	}

}
