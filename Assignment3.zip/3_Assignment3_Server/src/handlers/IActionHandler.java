package handlers;

import java.util.Vector;

public interface IActionHandler {
	
	public Vector<String> getFileList();
	
	public byte[] downloadFile(String filename);
	
	public String uploadFile(byte[] fileContent, String filename);
}
