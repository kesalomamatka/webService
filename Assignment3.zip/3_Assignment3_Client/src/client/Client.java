package client;

import handlers.IActionHandler;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.*;

import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;
import org.apache.xmlrpc.client.util.ClientFactory;

public class Client extends JFrame {

	private static final long serialVersionUID = 1L;
	private static IActionHandler action;



	public Client() {}
	

	public static void main(String[] args) {

		try {

			XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();

			config.setServerURL(new URL(
					"http://app3.cc.puv.fi/3_Assignment3_Server_z/xmlrpc"));

			config.setBasicUserName("tomcat");

			config.setBasicPassword("tomcat");
			
			XmlRpcClient client = new XmlRpcClient();

			client.setConfig(config);

			// In the following we use dynamic proxy
			ClientFactory clientFactory = new ClientFactory(client);
			action = (IActionHandler) clientFactory.newInstance(IActionHandler.class);

	
			
			boolean flag = true;
			
			while(flag){
				System.out.println("------Enter------\n1.Get File List\n2.Upload File\n3.Download File\n");
				Scanner scanner = new Scanner(System.in);
				int choose = scanner.nextInt();
				
				if(choose==1){	
					Vector<String> vector = action.getFileList();
					Iterator value = vector.iterator(); 
					System.out.println("File list: "); 
			        while (value.hasNext()) { 
			            System.out.println(value.next()); 
			        } 
			        
					
				}else if(choose==2){
					System.out.println("Enter the absolute path: "); 
					String absPath = scanner.next();
					 
					System.out.println("Enter the the file name to upload: "); 
					String fileName = scanner.next();
					
					Path path = Paths.get(absPath+File.separator+fileName);
					byte[] content = null;
					try {
						content = Files.readAllBytes(path);

						System.out.println(action.uploadFile(content,fileName ));
					} catch (IOException e) {
						System.out.println(e.getMessage());
					}
					
					
				}else if(choose==3){
					System.out.println("Enter file name to download: \n"); 
					String filename =  scanner.next();
					
					System.out.println("Enter path to save file: \n"); 
					String savePath =  scanner.next();

					byte[] content = action.downloadFile(filename);
					Path path = Paths.get(savePath + File.separator + filename);
					try {
						Files.write(path, content);
						System.out.println("Success \n"); 

					} catch (IOException e) {
						System.out.println("error"+ e.getMessage());
					}
					
				}else System.out.println("Invalid input");
				
			}
			
			
			
			
			
	
			

		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		}

	}

}