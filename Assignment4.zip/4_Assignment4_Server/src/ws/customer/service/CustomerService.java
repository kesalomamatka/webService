package ws.customer.service;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;

import ws.customer.data.Customer;

public class CustomerService {

	// Here we define a collection for customers.
	Hashtable<Integer, Customer> customers = new Hashtable<Integer, Customer>();

	public int setCustomer(Customer customer) {
		customers.put(customer.getCustomerID(), customer);
		return customers.size();
	}

	public Customer getCustomer(int id) {
		Customer customer = customers.get(id);
		return customer == null ? new Customer() : customer;
	}
	public Customer[] getCustomerInShoppingAmountRange(float min, float max) {
		List<Customer> response = new ArrayList<Customer>();
		
		Collection<Customer> customerCol = customers.values();
		//iterate customer find the customer in the min and max range
		for (Customer cus : customerCol) {
			if (cus.getShoppingAmount() > min && cus.getShoppingAmount() < max) {
				response.add(cus);
			}
		}
		//https://www.geeksforgeeks.org/arraylist-array-conversion-java-toarray-methods/

		//Convert arraylist to array
		Customer[] customerArray = new Customer[response.size()];
		return response.toArray(customerArray);
	}


}