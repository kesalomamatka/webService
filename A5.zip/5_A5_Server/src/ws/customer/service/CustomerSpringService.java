//The following is the content of file /ws/customer/service/CustomerSpringService.java

package ws.customer.service;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import ws.customer.data.Customer;

public class CustomerSpringService {

	private HashMap<Integer, Customer> customers;
	
	public CustomerSpringService() {
		this.customers = new HashMap<Integer, Customer>();
	}
	
	public HashMap<Integer, Customer> getCustomers() {
		return customers;
	}
	
	public void setCustomers(HashMap<Integer, Customer> customers) {
		this.customers = new HashMap<Integer, Customer>(customers);
	}

	public Customer getCustomerByID(Integer id) {
		return customers.get(id);
	}
	
	public List<Integer> getAllId() {
		return new ArrayList<Integer>(customers.keySet());
	}
	
	public Customer getCustomerWithHighestAmount() {
		if(customers.isEmpty()) {
			return null;
		}
		//Returns the next element.
		Customer response = customers.values().iterator().next();
		for (Customer c : customers.values()) {
			if(c.getShoppingAmount() > response.getShoppingAmount()) {
				response = c;
			}
		}
		
		return response;
	}
	
	public List<Customer> getCustomerByPrivileged(boolean privileged) {
		List<Customer> response = new ArrayList<Customer>();
		for (Customer c : customers.values()) {
			if(c.getPrivileged() == privileged) {
				response.add(c);
			}
		}
		
		return response;
	}
}