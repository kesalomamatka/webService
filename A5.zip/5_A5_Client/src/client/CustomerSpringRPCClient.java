package client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import javax.xml.namespace.QName;

import org.apache.axis2.AxisFault;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.rpc.client.RPCServiceClient;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import data.Customer;

public class CustomerSpringRPCClient {
	
	private final String serviceNamespace = "http://service.customer.ws";
	private RPCServiceClient serviceClient;
	
	public CustomerSpringRPCClient(String endPoint) throws AxisFault {
		serviceClient = new RPCServiceClient();
		Options options = serviceClient.getOptions();
		EndpointReference targetEPR = new EndpointReference(endPoint);
		options.setTo(targetEPR);
	}
	
	
	
	public List<Integer> getAllId() throws AxisFault {
		QName opGetCustomer = new QName(serviceNamespace, "getAllId");
		Object[] opGetCustomerArgs = new Object[] { };
		Class[] returnTypes = new Class[] { Integer[].class };
		Object[] response = serviceClient.invokeBlocking(opGetCustomer, opGetCustomerArgs, returnTypes);
		Integer[] result = (Integer[])response[0];
		return Arrays.asList(result);
	}
	
	public Customer getCustomerWithHighestAmount() throws AxisFault {
		QName opGetCustomer = new QName(serviceNamespace, "getCustomerWithHighestAmount");
		Object[] opGetCustomerArgs = new Object[] { };
		Class[] returnTypes = new Class[] { Customer.class };
		Object[] response = serviceClient.invokeBlocking(opGetCustomer, opGetCustomerArgs, returnTypes);
		return (Customer)response[0];
	}
	
	public List<Customer> getCustomerByPrivileged(boolean privileged) throws AxisFault {
		QName opGetCustomer = new QName(serviceNamespace, "getCustomerByPrivileged");
		Object[] opGetCustomerArgs = new Object[] { privileged };
		Class[] returnTypes = new Class[] { Customer[].class };
		Object[] response = serviceClient.invokeBlocking(opGetCustomer, opGetCustomerArgs, returnTypes);
		Customer[] result = (Customer[])response[0];
		return Arrays.asList(result);
	}
	
	private static void init() {
		BasicConfigurator.configure();
		Logger log = Logger.getLogger(CustomerSpringRPCClient.class);
		log.setLevel(Level.DEBUG);
		log.debug("Debug message");
		log.info("INFO message");
		log.warn("Warning message");
		log.error("Error message");
		log.fatal("Fatal");
		// log.log(Level.SEVERE, "Hello from logger");
	}
	
	public static void printCustomer(Customer customer) {
		System.out.println("Customer name : " + customer.getCustomerName());
		System.out.println("Customer ID : " + customer.getCustomerID());
		System.out.println("Shopping amount : " + customer.getShoppingAmount());
		System.out.println("Customer is privileged? : " + customer.getPrivileged());
		System.out.println("Discount amount : " + customer.getDiscount());
	}
	private final static String ENDPOINT = "http://app3.cc.puv.fi/axis2/services/e1500951_A5_CustomerSpringService_In";

	public static void main(String[] args1) {
		// init log
		init();

		try {
			// init service client
			CustomerSpringRPCClient client = new CustomerSpringRPCClient(ENDPOINT);

			
			boolean flag = true;
			while(flag){
				System.out.println("------Enter------\n1.All ID\n2.Get Customer With Highest Ammount\n3.Get Customer by Privileged");
				
				Scanner scanner = new Scanner(System.in);
				int choose = scanner.nextInt();
				
				if(choose ==1){
					// operate with service
					List<Integer> ids = client.getAllId();
					System.out.println("The id are: " + ids); 
					
				}else if(choose ==2){
					Customer customer2 = client.getCustomerWithHighestAmount();
					printCustomer(customer2);
					
				}else if(choose ==3){
					System.out.println("1.True 2.False");
					int id = scanner.nextInt();
					boolean ans=true;
					if(id == 1) ans=true; 
					else if(id==2) ans=false;
						
					List<Customer> customers = client.getCustomerByPrivileged(ans);
					for (Customer c : customers) {
						printCustomer(c);
					}
				}else System.out.println("try again");
				
				
			}
		} catch (AxisFault e) {
			e.printStackTrace();
		}
	}
}









/*
 * 



public Customer getCustomerByID(int id) throws AxisFault {
		QName opGetCustomer = new QName(serviceNamespace, "getCustomerByID");
		Object[] opGetCustomerArgs = new Object[] { id };
		Class[] returnTypes = new Class[] { Customer.class };
		Object[] response = serviceClient.invokeBlocking(opGetCustomer, opGetCustomerArgs, returnTypes);
		return (Customer)response[0];
	}
	
	
	
 * else if(choose ==2){
					System.out.println("Enter ID:\n");
					int id = scanner.nextInt();
					
					Customer customer1 = client.getCustomerByID(id);
					if(customer1==null) 	System.out.println("d");
						
					//printCustomer(customer1);
					
				}*/

